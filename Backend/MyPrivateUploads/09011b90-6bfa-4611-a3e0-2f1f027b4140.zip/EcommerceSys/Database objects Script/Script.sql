use [E-Commerce]


  
  go
  CREATE or ALTER TRIGGER trg_UpdatePaymentStatus
ON Payments
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
  

    -- Declare a table variable to store affected OrderIDs
    DECLARE @AffectedOrders TABLE (OrderID INT);

    -- Insert affected OrderIDs from inserted and deleted tables
    INSERT INTO @AffectedOrders (OrderID)
    SELECT OrderID FROM inserted
    UNION
    SELECT OrderID FROM deleted;

    -- Update PaymentStatus in Orders table for affected orders
    UPDATE O
    SET O.PaymentStatus = 
        CASE 
            WHEN ISNULL(P.TotalPaid, 0) = O.TotalAmount THEN 'Paid'
            WHEN ISNULL(P.TotalPaid, 0) < O.TotalAmount THEN 'Partially Paid'
            ELSE 'Unpaid'
        END
    FROM Orders O
    LEFT JOIN (
        SELECT 
            OrderID,
            SUM(Amount) AS TotalPaid
        FROM Payments
        WHERE Status = 'Completed'
        GROUP BY OrderID
    ) P ON O.OrderID = P.OrderID
    WHERE O.OrderID IN (SELECT OrderID FROM @AffectedOrders);
END;


GO
CREATE or ALTER TRIGGER trg_CalculateOrderItemPrice
ON OrderItems
INSTEAD OF INSERT
AS
BEGIN
    -- Check if any inserted order item exceeds available stock
    IF EXISTS (
        SELECT 1
        FROM inserted I
        INNER JOIN products P ON I.ProductID = P.ProductID
        WHERE I.Quantity > P.stock
    )
    BEGIN
        RAISERROR('Cannot place order: Insufficient stock for one or more products.', 16, 1);
        RETURN; -- Stop further execution
    END;

    -- Insert valid order items with calculated Price
    INSERT INTO OrderItems (OrderID, ProductID, Quantity, Price)
    SELECT 
        I.OrderID,
        I.ProductID,
        I.Quantity,
        P.price * I.Quantity AS Price -- Calculate Price
    FROM inserted I
    INNER JOIN products P ON I.ProductID = P.ProductID;

    -- Update TotalAmount in Orders table
    UPDATE O
    SET O.TotalAmount = (
        SELECT SUM(Price)
        FROM OrderItems
        WHERE OrderID = O.OrderID
    )
    FROM Orders O
    WHERE O.OrderID IN (SELECT DISTINCT OrderID FROM inserted);
END;
GO


--discount to a specific product
create or alter proc Discount  @ProductID int , @Dis int 
as
update products 
set price = price - (price*(@Dis/100))
where productID = @ProductID


go
--user soft delete
create or alter trigger UserSoftDelete 
on users
instead of delete
as 
begin 
update users 
set isactive = 0 
where userid in (select userid from deleted)
end 

go
--decrease stock of product after making order
create or alter trigger DecreaseStockByOne
on orderitems
after insert
as
begin 
update products set stock = stock - inserted.quantity  
from products , inserted
where products.productID = inserted.ProductID
end


GO
CREATE OR ALTER VIEW vw_Top20MostSellingProducts
AS
SELECT TOP 20
    P.ProductID,
    P.name,
    SUM(OI.Quantity) AS TotalQuantitySold
FROM OrderItems OI
INNER JOIN products P ON OI.ProductID = P.ProductID
GROUP BY P.ProductID, P.name
ORDER BY TotalQuantitySold DESC;


SELECT * FROM vw_Top20MostSellingProducts;

GO
CREATE OR ALTER TRIGGER trg_InsertOnOrders
ON [E-Commerce].[dbo].[Orders]
INSTEAD OF INSERT
AS
BEGIN
    -- Insert data with enforced rules
    INSERT INTO [E-Commerce].[dbo].[Orders] (
        [UserID], 
        [OrderDate], 
        [TotalAmount], 
   
        [PaymentStatus]
    )
    SELECT 
        [UserID], 
        GETDATE(), 
        0 AS [TotalAmount],         -- Set TotalAmount to 0
       
        'Unpaid' AS [PaymentStatus] -- Set PaymentStatus to 'Unpaid'
    FROM INSERTED;
END;











	GO
	CREATE or alter PROCEDURE UpdateProductAverageRating
AS
BEGIN
    UPDATE p
    SET p.AverageRating = avgRatings.AverageRating
    FROM Products p
    INNER JOIN (
        SELECT 
            r.ProductID, 
            CONVERT(FLOAT, AVG(CAST(r.Rating AS FLOAT))) AS AverageRating
        FROM 
            Reviews r
        GROUP BY 
            r.ProductID
    ) avgRatings ON p.ProductID = avgRatings.ProductID;
END;


EXEC UpdateProductAverageRating;


go
CREATE or Alter PROCEDURE UpdateWishlistWithTopProducts
AS
BEGIN
    -- Step 1: Reset the identity column to 0
    DBCC CHECKIDENT ('Wishlists', RESEED, 0);

    -- Step 2: Delete all existing entries from the Wishlist table
    DELETE FROM Wishlists;

    -- Step 3: Insert the top 3 products for each user into the Wishlist table
    WITH UserPurchases AS (
        SELECT
            o.UserID,
            oi.ProductID,
            SUM(oi.Quantity) AS TotalQuantity, -- Total quantity purchased for each product
            ROW_NUMBER() OVER (PARTITION BY o.UserID ORDER BY SUM(oi.Quantity) DESC) AS PurchaseRank
        FROM
            OrderItems oi
        INNER JOIN
            Orders o ON oi.OrderID = o.OrderID
        GROUP BY
            o.UserID, oi.ProductID
    )
    INSERT INTO Wishlists (UserID, ProductID, CreatedAt)
    SELECT
        UserID,
        ProductID,
        GETDATE() AS CreatedAt -- Set the current date and time
    FROM
        UserPurchases
    WHERE
        PurchaseRank <= 3; -- Only include the top 3 products for each user
END;

EXEC UpdateWishlistWithTopProducts;

go
CREATE or alter VIEW Top10ProductRating AS
SELECT TOP(10) p.productID, 
       p.name AS productName, 
       p.AverageRating,  
       COUNT(r.reviewID) AS review_count
FROM products p
 JOIN reviews r ON p.productID = r.productID
GROUP BY p.productID, p.name, p.AverageRating



go
CREATE TRIGGER trg_CheckStock
ON [E-Commerce].[dbo].[products]
AFTER UPDATE
AS
BEGIN
    -- Check if the stock is less than 10 for any updated rows
    IF EXISTS (SELECT 1 FROM inserted WHERE stock < 10)
    BEGIN
        -- Display a message when stock is less than 10
        PRINT 'Warning: Stock is less than 10 for one or more products.';
    END
END;